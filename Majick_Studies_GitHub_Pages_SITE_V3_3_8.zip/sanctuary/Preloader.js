class Preloader extends Phaser.Scene
{
    constructor()
    {
        super('Preloader');
    }

    preload()
    {
        const w = this.cameras.main.width;
        const h = this.cameras.main.height;
        this.add.text(w / 2, h / 2 - 44, 'Awakening the familiars…', {
            fontFamily: 'Georgia', fontSize: '26px', color: '#f4d19a'
        }).setOrigin(0.5);
        const track = this.add.rectangle(w / 2, h / 2 + 6, 430, 16, 0x2f1938, 0.95);
        track.setStrokeStyle(2, 0xe0b776, 0.45);
        const bar = this.add.rectangle(w / 2 - 211, h / 2 + 6, 1, 10, 0xe0b776, 0.95).setOrigin(0, 0.5);
        const percent = this.add.text(w / 2, h / 2 + 42, '0%', {
            fontFamily: 'Arial', fontSize: '14px', color: '#f7e9f1'
        }).setOrigin(0.5);
        this.load.on('progress', value => { bar.width = Math.max(1, 422 * value); percent.setText(Math.round(value * 100) + '%'); });
        this.load.on('complete', () => { const n = document.getElementById('phaser-load-note'); if (n) n.style.display = 'none'; });
        this.load.on('loaderror', file => console.warn('Sanctuary asset failed to load:', file && file.key));

        const base =
            'https://raw.githubusercontent.com/rnw4512-dev/majick-studies-assets/main/';

        // Local academy art keeps the room feeling like a real magical college.
        this.load.image('academy-sanctuary-bg', '../assets/academy_hero.jpg');


        // =====================================================
        // LUNA
        // =====================================================

        this.load.image('luna-idle', base + 'luna-idle.png');
        this.load.image('luna-walk-1', base + 'luna-walk-1.png');
        this.load.image('luna-walk-2', base + 'luna-walk-2.png');
        this.load.image('luna-hop', base + 'luna-hop.png');

        // Keep the safe Luna fallbacks that were working.
        this.load.image('luna-paw', base + 'luna-hop.png');
        this.load.image('luna-sit', base + 'luna-idle.png');
        this.load.image('luna-sleep', base + 'luna-idle.png');


        // =====================================================
        // EMBER
        // =====================================================

        this.load.image('ember-idle', base + 'ember-idle.png');
        this.load.image('ember-walk-1', base + 'ember-walk-1.png');
        this.load.image('ember-walk-2', base + 'ember-walk-2.png');
        this.load.image('ember-hop', base + 'ember-hop.png');
        this.load.image('ember-slither-1', base + 'ember-slither-1.png');
        this.load.image('ember-slither-2', base + 'ember-slither-2.png');
        this.load.image('ember-sit', base + 'ember-sit.png');
        this.load.image('ember-sleep', base + 'ember-sleep.png');


        // =====================================================
        // NOVA
        // =====================================================

        // IMPORTANT:
        // Preserve the fallback that previously allowed the game to run.
        // We will repair Nova separately after Mallow is working.
        this.load.image('nova-idle', base + 'nova-sit.png');

        this.load.image('nova-walk-1', base + 'nova-walk-1.png');
        this.load.image('nova-walk-2', base + 'nova-walk-2.png');
        this.load.image('nova-run', base + 'nova-run.png');
        this.load.image('nova-hop', base + 'nova-hop.png');
        this.load.image('nova-paw', base + 'nova-paw.png');
        this.load.image('nova-spin', base + 'nova-spin.png');
        this.load.image('nova-sit', base + 'nova-sit.png');
        this.load.image('nova-sleep', base + 'nova-sleep.png');
        this.load.image('nova-pounce', base + 'nova-pounce.png');
        this.load.image('nova-pounce2', base + 'nova-pounce2.png');
        this.load.image('nova-pounce3', base + 'nova-pounce3.png');


        // =====================================================
        // MALLOW
        // =====================================================

        this.load.image('mallow-idle', base + 'mallow-idle.png');
        this.load.image('mallow-hop-1', base + 'mallow-hop-1.png');
        this.load.image('mallow-hop-2', base + 'mallow-hop-2.png');
        this.load.image('mallow-fly-1', base + 'mallow-fly%201.png');
        this.load.image('mallow-fly-2', base + 'mallow-fly%202.png');
        this.load.image('mallow-paw', base + 'mallow-paw.png');
        this.load.image('mallow-sit', base + 'mallow-sit.png');
        this.load.image('mallow-sleep', base + 'mallow-sleep.png');
        this.load.image('mallow-land', base + 'mallow-land.png');
        this.load.image('mallow-binky', base + 'mallow-binky.png');
    }

    create()
    {
        this.scene.start('Game');
    }
}