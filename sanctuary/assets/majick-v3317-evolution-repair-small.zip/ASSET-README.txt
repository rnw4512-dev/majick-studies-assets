Majick Studies V3.3.17 — Guardian Evolution Repair

This ZIP contains 60 individual Phaser-ready Guardian assets:
4 Guardians × 5 evolution stages × 3 actions.

Upload this ZIP to:
sanctuary/assets/majick-v3317-evolution-repair.zip

Do NOT place these files in sanctuary/assets/motion/.
The original 33 motion PNGs remain protected.

Folder structure inside this ZIP already matches:
sanctuary/assets/evolutions/<guardian>/<stage>/<walk|play|sleep>.webp

Canvas: 1024×1024 transparent WebP
