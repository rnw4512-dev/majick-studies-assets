Majick Studies V3.3.17 — FINAL CLEAN Guardian Evolution Actions

60 individual Phaser-ready WebPs.
4 Guardians × 5 stages × walk/play/sleep.

Upload this ZIP to sanctuary/assets/ when instructed.
Do NOT place any of these files in sanctuary/assets/motion/.
The original 33 Phase 4 motion files remain protected.
